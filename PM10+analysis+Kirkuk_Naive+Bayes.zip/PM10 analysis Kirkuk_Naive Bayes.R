#PM 10 prediction using machine learning supervised classification techniques.

# 1 Introduction ------------------------------------------------------------


##################################################.
## Project: PM 10 prediction using machine learning supervised classification techniques.
## Script purpose:Naive Bayes (NB) in CARET package
## Date: 28 Feb. 2019
## Author: Omar AlThuwaynee
##################################################.

# Disclaimer:
#            As with most of my R posts, I've arranged the functions using ideas from other people that are much more clever than me. 
#            I've simply converted these ideas into a useful form in R.
# References


######################
#### 1 Data prepration ---------------------------------------------------------
######################
# Go to URL of local folder and select and Copy. (G:\IKC\International projects\Kirkuk air pollution\Data\pm10)

# Go to URL of local folder and select and Copy.(H:\Projects\Kirkuk\WorkingDir)
path=readClipboard()
setwd(path)
getwd() # for checking
.libPaths("G:/IKC/International projects/Kirkuk air pollution/Data/pm10/pm10 library")

# Install packages
install.packages("RStoolbox")    # Image analysis & plotting spatial data 
library(rgdal)        # spatial data processing
library(raster)       # raster processing
library(plyr)         # data manipulation 
library(dplyr)        # data manipulation 
library(RStoolbox)    # Image analysis & plotting spatial data 
library(RColorBrewer) # color
library(ggplot2)      # plotting
library(sp)           # spatial data
library(caret)        # machine laerning
library(doParallel)   # Parallel processing
library(e1071)        # Naive Bayes


# Step 1: Import training and testing data ----
list.files( pattern = "csv$", full.names = TRUE)

# Import training and testing data ----
list.files( pattern = "csv$", full.names = TRUE)
original <-  read.csv("./stat_all_no_road.csv", header = T,stringsAsFactors = FALSE)
road <-  read.csv("./stat_road.csv", header = T)
original$dis_to_road=road$disttoroadR
original <-(na.omit(original))
original <-data.frame(original)  # to remove the unwelcomed attributes

#Step 2: Data Cleaning
names(original) 
original <- original[c("LevelAve" ,"BU..MEAN.",   "LST..MEAN." , "SAVI..MEAN." ,"band2..MEAN", 
                       "band3..MEAN", "band4..MEAN" ,"band5..MEAN", "band6..MEAN", "dis_to_road")] # remove unnecessary variables
names(original)
original$LevelAve=as.factor(original$LevelAve)


#Step 3: Data Normalization
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }

names(original)
original.n <- as.data.frame(lapply(original[,2:10], normalize)) # Keep the "LevelAve" variables since it the response variable that needs to be predicted.                     


#Step 2: Data Visualization
names(original)
old.par <- par(mfrow=c(3, 2))

#Visual Land surface temprature
ggplot(original, aes(LST..MEAN., colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Temprature Distribution by PM10 limits")

#Visual Dis_to_road
ggplot(original, aes(dis_to_road, colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Dis to road Distribution by PM10 limits")

#Visual Bands 2
ggplot(original, aes(band2..MEAN, colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Band 2 blue : Distribution by PM10 limits")

#Visual Band 3
ggplot(original, aes(band3..MEAN, colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Band 3 Green : Distribution by PM10 limits")

#Visual Band 4
ggplot(original, aes(band4..MEAN, colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Band 4 Red: Distribution by PM10 limits")

#Visual Band 5 measures the near infrared, or NIR. This part of the spectrum is especially important
#                for ecology because healthy plants reflect it – the water in their leaves scatters the 
#               wavelengths back into the sky. By comparing it with other bands, we get indexes like NDVI, 
#               which let us measure plant health more precisely than if we only looked at visible greenness
ggplot(original, aes(band5..MEAN, colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Band 5 NIR: Distribution by PM10 limits")

#Visual Band 6 Bands 6 and 7 cover different slices of the shortwave infrared, or SWIR. They are particularly useful 
#               for telling wet earth from dry earth, and for geology: rocks and soils that look similar in other 
#                 bands often have strong contrasts in SWIR
ggplot(original, aes(band6..MEAN, colour = LevelAve)) +
  geom_freqpoly(binwidth = 1) + labs(title="Band 6 SWIR: Distribution by PM10 limits")

par(old.par)

dev.off()


##### to predict which variable would be the best one for splitting the Decision Tree. 
#For this reason, I’ve plotted a graph that represents the split for each of the 9 variables, ####

#Creating seperate dataframe for '"LevelAve" features which is our target.
number.perfect.splits <- apply(X=original.n, MARGIN = 2, FUN = function(col){
  t <- table(original$LevelAve,col)
  sum(t == 0)})

# Descending order of perfect splits
order <- order(number.perfect.splits,decreasing = TRUE)
number.perfect.splits <- number.perfect.splits[order]

# Plot graph
par(mar=c(10,2,2,2))
barplot(number.perfect.splits,main="Number of perfect splits vs feature",xlab="",ylab="Feature",las=3,col="wheat") # SAVI and LST are the best classifiers



#Step 4: Data Splicing
set.seed(123)
data.d <- sample(1:nrow(original),size=nrow(original)*0.65,replace = FALSE) #random selection of 65% data.
train.data <- original.n[data.d,] # 65% training data
test.data <- original.n[-data.d,] # remaining 35% test data

#Creating seperate dataframe for '"LevelAve" features which is our target.
train.data_labels <- original[data.d,1]
test.data_labels <-original[-data.d,1]

train.data$PM=train.data_labels


# Vairables visualization
#install.packages("GGally")
install.packages("doSNOW")
install.packages("klaR")

library(GGally)
library(doSNOW)
library(klaR)

#install.packages("Rtools")
#library(Rtools)
#Start many iterations foreach to parallelize for model fitting
#mc <- makeCluster(detectCores())
#registerDoParallel(mc)


######################
#### 2 Modeling ---------------------------------------------------------
######################

# Step 1 Run the modelling
# Using default prameters
myControl <- trainControl(method="repeatedcv", 
                          number=10, 
                          repeats=3,
                          returnResamp='all', 
                          allowParallel=TRUE)


#Train Na?ve Bayes model
#We will use the train() function of the caret package with the "method" parameter "nb" wrapped from the e1071 package.
set.seed(849)
fit.nb_def <- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ band5..MEAN+ band6..MEAN+dis_to_road, 
                    data=train.data,
                method = "nb",
                metric= "Accuracy",
                preProc = c("center", "scale"),
                trControl = myControl)
fit.nb_def$resample 
X.nb  = varImp(fit.nb_def)
plot(X.nb )

# Plot graph
# 1. Open jpeg file
jpeg("varImportance NB.jpg", width = 800, height = 500)
# 2. Create the plot
plot(X.nb,main="varImportance NB" )
# 3. Close the file
dev.off()

p1<-predict(fit.nb_def, test.data, type = "raw")
confusionMatrix(p1, test.data_labels)   # using more deep tree, the accuracy linearly increases! 


#Step 2: Tuning parameters: 

tune_gridNaive <- expand.grid(fL= c(0,0.5,1.0) ,             # (Laplace Correction)
                          usekernel= T ,                     #(Distribution Type)
                          adjust= c(0,0.5,1.0)              #(Bandwidth Adjustment)
                         )

#Train Na?ve Bayes model
#We will use the train() function of the caret package with the "method" parameter "nb" wrapped from the e1071 package.
set.seed(849)
fit.nb <- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ band5..MEAN+ band6..MEAN+dis_to_road, 
                data=train.data,
                method = "nb",
                tuneGrid=tune_gridNaive,
                metric= "Accuracy",
                preProc = c("center", "scale"), 
                trControl = myControl,
                importance = TRUE)
fit.nb$results 
summaryRes=fit.nb$results # nrounds was fixed = 210
head(summaryRes)
summary(summaryRes)
head(summaryRes[order(summaryRes$Accuracy, decreasing = TRUE),],n=6)  # sort max to min for first 5 values based on Accuracy


## using best tunned hyperparameters
tune_gridNaive2 <- expand.grid(fL= c(0) ,             # (Laplace Correction)
                              usekernel= T ,                     #(Distribution Type)
                              adjust= c(0.5)              #(Bandwidth Adjustment)
)

#Train Na?ve Bayes model
#We will use the train() function of the caret package with the "method" parameter "nb" wrapped from the e1071 package.
set.seed(849)
fit.nb2 <- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ band5..MEAN+ band6..MEAN+dis_to_road, 
                data=train.data,
                method = "nb",
                tuneGrid=tune_gridNaive2,
                metric= "Accuracy",
                preProc = c("center", "scale"), 
                trControl = myControl,
                importance = TRUE)
fit.nb2$results 



#Confusion Matrix - train data
p1<-predict(fit.nb2, test.data, type = "raw")
confusionMatrix(p1, test.data_labels)   # using more deep tree, the accuracy linearly increases! 
#while increase the iterations to 220 double the processing time with slight accuracy improvment!


# Plot ROC curves
# https://stackoverflow.com/questions/46124424/how-can-i-draw-a-roc-curve-for-a-randomforest-model-with-three-classes-in-r
#install.packages("pROC")
library(pROC)


# the model is used to predict the test data. However, you should ask for type="prob" here
predictions <- as.data.frame(predict(fit.nb2, test.data, type = "prob"))

##  Since you have probabilities, use them to get the most-likely class.
# predict class and then attach test class
predictions$predict <- names(predictions)[1:3][apply(predictions[,1:3], 1, which.max)]
predictions$observed <- test.data_labels
head(predictions)

#    Now, let's see how to plot the ROC curves. For each class, convert the multi-class problem into a binary problem. Also, 
#    call the roc() function specifying 2 arguments: i) observed classes and ii) class probability (instead of predicted class).
# 1 ROC curve,  VUnheal, Good, UHealSesn vs non  VUnheal non Good non UHealSesn
roc.Good <- roc(ifelse(predictions$observed=="Good", "Good", "non-Good"), as.numeric(predictions$Good))
roc.VUnheal <- roc(ifelse(predictions$observed== "VUnheal", "VUnheal", "non-VUnheal"), as.numeric(predictions$VUnheal))
roc.UHealSesn <- roc(ifelse(predictions$observed=="UHealSesn", "UHealSesn", "non-UHealSesn"), as.numeric(predictions$UHealSesn))

plot(roc.VUnheal, col = "#FF9900", main="NB best tune prediction ROC plot using testing data", xlim=c(0.64,0.1))
lines(roc.UHealSesn, col = "red")
lines(roc.Good, col = "green")

# calculating the values of AUC for ROC curve
results= c("UHealSesn AUC" = roc.UHealSesn$auc,"VUnheal AUC" = roc.VUnheal$auc,"Good AUC" = roc.Good$auc)
print(results)
legend("topleft",c("UHealSesn AUC = 0.75 ","VUnheal AUC = 0.84","Good AUC = 0.84"),fill=c("red","#FF9900","green"),inset = (0.42))


# Continue  https://stackoverflow.com/questions/47820166/add-auc-by-group-on-roc-plots-in-r

# for more professional plots: 
# https://stackoverflow.com/questions/14860078/plot-multiple-lines-data-series-each-with-unique-color-in-r
# http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf
# http://www.cookbook-r.com/Graphs/Shapes_and_line_types/
brewer.pal(n = 3, name = "RdBu")
# Plot colors
library("RColorBrewer")
display.brewer.all()


# Step 5 Train nb model USING aLL data
#We will use the train() function from the of caret package with the "method" parameter "xgbTree" wrapped from the XGBoost package.

original.n$PM=as.factor(original$LevelAve)

set.seed(849)
fit.nbAll<- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ band5..MEAN+ band6..MEAN+dis_to_road, 
                  data=original.n,
                method = "nb",
                metric= "Accuracy",
                tuneGrid=tune_gridNaive2,
                preProc = c("center", "scale"), 
                trControl = myControl)

fit.nbAll$results
X.xgbAll = varImp(fit.nbAll)
plot(X.xgbAll, main="varImportance All NB tuned")

# Plot graph
# 1. Open jpeg file
jpeg("varImportance All NB.jpg", width = 800, height = 500)
# 2. Create the plot
plot(X.xgbAll,main="varImportanceAll NB" )
# 3. Close the file
dev.off()


######################################
#### 3 Produce prediction maps using Raster data----------------
######################################

#Produce LSM map using Training model results and Raster layers data

# Import Raster
install.packages("raster")
install.packages("rgdal")
library(raster)
library(rgdal)

# Load the Raster data
list.files( "H:/Projects/Kirkuk/WorkingDir/LST_ave",pattern = "tif$", full.names = TRUE)
LST..MEAN. = raster("H:/Projects/Kirkuk/WorkingDir/LST_ave/LST.tif" )
names(LST..MEAN.)="LST..MEAN."

list.files( "H:/Projects/Kirkuk/WorkingDir/SAVI_ave",pattern = "tif$", full.names = TRUE)
SAVI..MEAN. <-  raster("H:/Projects/Kirkuk/WorkingDir/SAVI_ave/SAVI.tif" ) 
names(SAVI..MEAN.)="SAVI..MEAN."

list.files( "H:/Projects/Kirkuk/WorkingDir/BU_ave",pattern = "tif$", full.names = TRUE)
BU..MEAN.= raster("H:/Projects/Kirkuk/WorkingDir/BU_ave/BU.tif" ) 
names(BU..MEAN.)="BU..MEAN."

list.files( "H:/Projects/Kirkuk/WorkingDir/B2_ave",pattern = "tif$", full.names = TRUE)
band2..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B2_ave/band2.tif")
names(band2..MEAN)="band2..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B3_ave",pattern = "tif$", full.names = TRUE)
band3..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B3_ave/band3.tif") 
names(band3..MEAN)="band3..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B4_ave",pattern = "tif$", full.names = TRUE)
band4..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B4_ave/band4.tif" ) 
names(band4..MEAN)="band4..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B5_ave",pattern = "tif$", full.names = TRUE)
band5..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B5_ave/band5.tif" ) 
names(band5..MEAN)="band5..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B6_ave",pattern = "tif$", full.names = TRUE)
band6..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B6_ave/band6.tif" ) 
names(band6..MEAN)="band6..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/Roads",pattern = "tif$", full.names = TRUE)
dis_to_road= raster("H:/Projects/Kirkuk/WorkingDir/Roads/dist_to_road.tif" ) 
names(dis_to_road)="dis_to_road"
Study_area <- shapefile("G:/IKC/International projects/Kirkuk air pollution/Practical/study area focused.shp")
dis_to_road <- mask(crop(dis_to_road, Study_area), Study_area)


---------------#EXTRA----
# if you have diffrent extent, then try to Resample them using the smallest area
NDVI_r <- resample(NDVI,LST, resample='bilinear') 
SLOPE_r <- resample(SLOPE,LANDCOVER, resample='bilinear') 
TWI_r <- resample(TWI,LANDCOVER, resample='bilinear') 
CURVATURE_r <- resample(CURVATURE,LANDCOVER, resample='bilinear') 
SPI_r <- resample(SPI,LANDCOVER, resample='bilinear') 
ASPECT_r <- resample(ASPECT,LANDCOVER, resample='bilinear') 

extent(ASPECT_r) # check the new extent
extent(LANDCOVER)

# write to a new geotiff file
writeRaster(ASPECT_r,filename="resampled/ASPECT.tif", format="GTiff", overwrite=TRUE) 
writeRaster(SPI_r,filename="resampled/SPI.tif", format="GTiff", overwrite=TRUE)
writeRaster(CURVATURE_r,filename="resampled/CURVATURE.tif", format="GTiff", overwrite=TRUE)
writeRaster(TWI_r,filename="resampled/TWI.tif", format="GTiff", overwrite=TRUE)
writeRaster(ELEVATION_r,filename="resampled/ELEVATION.tif", format="GTiff", overwrite=TRUE)
writeRaster(SLOPE_r,filename="resampled/SLOPE.tif", format="GTiff", overwrite=TRUE)
writeRaster(LANDCOVER,filename="resampled/LANDCOVER.tif", format="GTiff", overwrite=TRUE)

#Stack_List= stack(ASPECT_r,LS_r)#,pattern = "tif$", full.names = TRUE)
#names(Stack_List)
#Stack_List.df = as.data.frame(Stack_List, xy = TRUE, na.rm = TRUE)
#head(Stack_List.df,1)

#--------------#-----

# stack multiple raster files

#Stack
Rasters<- stack(BU..MEAN.,LST..MEAN.,SAVI..MEAN.,band2..MEAN,band3..MEAN,band4..MEAN,band5..MEAN,band6..MEAN,dis_to_road)
plot(Rasters$LST..MEAN.)
names(Rasters)


#Convert raster to dataframe with Long-Lat
Rasters.df = as.data.frame(Rasters, xy = TRUE, na.rm = TRUE)
head(Rasters.df,1)
#Rasters.df=Rasters.df[,c(-6)] #

# Now:Prediction using imported Rasters
Rasters.df_N <- Rasters.df[,c(-1,-2)] # remove x, y

# Data Normalization
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }
# Keep the "LevelAve" variables since it’s the response variable that needs to be predicted.
names(original)
Rasters.df_N_Nor <- as.data.frame(lapply(Rasters.df_N, normalize))    
str(Rasters.df_N_Nor)


#Convert Dataframe back to raster with Long-Lat
#https://stackoverflow.com/questions/19627344/how-to-create-a-raster-from-a-data-frame-in-r


#### PRODUCE PROBABILITY MAP ####
p3<-as.data.frame(predict(fit.nbAll, Rasters.df_N_Nor, type = "prob"))
summary(p3)
Rasters.df$Levels_VUnheal<-p3$VUnheal
Rasters.df$Levels_good<-p3$Good
Rasters.df$Levels_UHealSesn<-p3$UHealSesn

x<-SpatialPointsDataFrame(as.data.frame(Rasters.df)[, c("x", "y")], data = Rasters.df)
r_ave_good <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Levels_good")])
proj4string(r_ave_good)=CRS(projection(SAVI..MEAN.))

r_ave_VUnheal <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Levels_VUnheal")])
proj4string(r_ave_VUnheal)=CRS(projection(SAVI..MEAN.))

r_ave_UHealSesn <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Levels_UHealSesn")])
proj4string(r_ave_UHealSesn)=CRS(projection(SAVI..MEAN.))

# Plot Maps
spplot(r_ave_VUnheal, main="VUnheal NB")
writeRaster(r_ave_VUnheal,filename="Prediction_NB Tunned_Ave_VUnheal.tif", format="GTiff", overwrite=TRUE) 

spplot(r_ave_UHealSesn, main="UHealSesn NB")
writeRaster(r_ave_UHealSesn,filename="Prediction_NB Tunned_Ave_UHealSesn.tif", format="GTiff", overwrite=TRUE) 

spplot(r_ave_good, main="GOOD NB")
writeRaster(r_ave_good,filename="Prediction_NB Tunned_Ave_GOOD.tif", format="GTiff", overwrite=TRUE) 



#### PRODUCE CLASSIFICATION MAP ####

#Prediction at grid location
p3<-as.data.frame(predict(fit.nbAll , Rasters.df_N_Nor, type = "raw"))
summary(p3)
# Extract predicted levels class
head(Rasters.df, n=2)
Rasters.df$Levels_ave<-p3$`predict(fit.nbAll, Rasters.df_N_Nor, type = "raw")`
head(Rasters.df, n=2)

# Import levels ID file 
ID<-read.csv("./Levels_key.csv", header = T)

# Join landuse ID
grid.new<-join(Rasters.df, ID, by="Levels_ave", type="inner") 
# Omit missing values
grid.new.na<-na.omit(grid.new)    
head(grid.new.na, n=2)

#Convert to raster
x<-SpatialPointsDataFrame(as.data.frame(grid.new.na)[, c("x", "y")], data = grid.new.na)
r_ave <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Level_ID")])

# coord. ref. : NA 
# Add coord. ref. system by using the original data info (Copy n Paste).
# borrow the projection from Raster data
proj4string(r_ave)=CRS(projection(SAVI..MEAN.)) # set it to lat-long

# Export final prediction map as raster TIF ---------------------------
# write to a new geotiff file
writeRaster(r_ave,filename="Classification_Map NB Tunned_Ave.tif", format="GTiff", overwrite=TRUE) 

#Plot Landuse Map:
# Color Palette follow Air index color style
#https://bookdown.org/rdpeng/exdata/plotting-and-color-in-r.html

myPalette <- colorRampPalette(c("light green","#FFFF00","#FFC600", "#FFAA00","#FF3800","#FF0000" ))

# Plot Map
LU_ave<-spplot(r_ave,"Level_ID", main="PM10 ave. concentration prediction: Naive Bayes" , 
               colorkey = list(space="right",tick.number=1,height=1, width=1.5,
                               labels = list(at = seq(1,4.8,length=5),cex=1.0,
                                             lab = c("Good" ,"Moderate", "UHealSesn", "UHeal", "VUnheal", "Haz"))),
               col.regions=myPalette,cut=4)
LU_ave
jpeg("Prediction_Map NB_AveAll.jpg", width = 1000, height = 700)
LU_ave
dev.off()


