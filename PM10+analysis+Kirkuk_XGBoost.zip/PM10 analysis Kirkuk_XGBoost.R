
# 1 Introduction ------------------------------------------------------------


##################################################.
## Project: PM 10 prediction using machine learning supervised classification techniques.
## Script purpose:Extreme Gradient Boosting (XGBoost) in CARET package
## Date: 07 Jan. 2020
## Author: Omar AlThuwaynee
##################################################.

# Disclaimer:
#            As with most of my R posts, I've arranged the functions using ideas from other people that are much more clever than me. 
#            I've simply converted these ideas into a useful form in R.
# References

#1#   https://www.hackerearth.com/practice/machine-learning/machine-learning-algorithms/beginners-tutorial-on-xgboost-parameter-tuning-r/tutorial/
#2#   https://www.analyticsvidhya.com/blog/2016/01/xgboost-algorithm-easy-steps/


# 2 Data prepration ---------------------------------------------------------
# Go to URL of local folder and select and Copy. (H:\IKC\International projects\Kirkuk air pollution\Data\pm10)



# Go to URL of local folder and select and Copy.(H:\Projects\Kirkuk\WorkingDir)
path=readClipboard()
setwd(path)
getwd() # for checking
.libPaths("G:/IKC/International projects/Kirkuk air pollution/Data/pm10/pm10 library")
#.libPaths("C:/Users/user/Desktop/WorkingDIR/libraryfake")
#.libPaths()
sessionInfo()
#installed.packages()
#"aish"="Hawaaaa"

# Install packages
install.packages("xgboost")
install.packages("rlang")
install.packages("doSNOW")
install.packages("RStoolbox") 
install.packages("doParallel")
install.packages("Matrix")
install.packages("e1071")

library(xgboost)
library(rgdal)        # spatial data processing
library(raster)       # raster processing
library(plyr)         # data manipulation 
library(dplyr)        # data manipulation 
library(RStoolbox)    # plotting spatial data 
library(RColorBrewer) # color
library(ggplot2)      # plotting
library(sp)           # spatial data
library(caret)        # machine laerning
library(doParallel)   # Parallel processing
library(doSNOW)
library(e1071)



# Import training and testing data ----
list.files( pattern = "csv$", full.names = TRUE)
original <-  read.csv("./stat_all_no_road.csv", header = T,stringsAsFactors = FALSE)
road <-  read.csv("./stat_road.csv", header = T)
original$dis_to_road=road$disttoroadR
original <-(na.omit(original))
original <-data.frame(original)  # to remove the unwelcomed attributes

#Step 2: Data Cleaning
names(original) 
original <- original[c("LevelAve" ,"BU..MEAN.",   "LST..MEAN." , "SAVI..MEAN." ,"band2..MEAN", 
                       "band3..MEAN", "band4..MEAN" ,"band5..MEAN", "band6..MEAN", "dis_to_road")] # remove unnecessary variables
names(original)
original$LevelAve=as.factor(original$LevelAve)


#Step 3: Data Normalization
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }

names(original)
original.n <- as.data.frame(lapply(original[,2:10], normalize)) # Keep the "LevelAve" variables since it the response variable that needs to be predicted.                     


##### to predict which variable would be the best one for splitting the Decision Tree, plot a graph that represents the split for each of the 9 variables, ####

#Creating seperate dataframe for '"LevelAve" features which is our target.
number.perfect.splits <- apply(X=original.n, MARGIN = 2, FUN = function(col){
  t <- table(original$LevelAve,col)
  sum(t == 0)})

# Descending order of perfect splits
order <- order(number.perfect.splits,decreasing = TRUE)
number.perfect.splits <- number.perfect.splits[order]

# Plot graph
par(mar=c(10,2,2,2))
barplot(number.perfect.splits,main="Number of perfect splits vs feature",xlab="",ylab="Feature",las=3,col="wheat") # SAVI and LST are the best classifiers


#Step 4: Data Splicing
set.seed(123)
data.d <- sample(1:nrow(original),size=nrow(original)*0.65,replace = FALSE) #random selection of 65% data.
train.data <- original.n[data.d,] # 65% training data
test.data <- original.n[-data.d,] # remaining 35% test data

#Creating seperate dataframe for '"LevelAve" features which is our target.
train.data_labels <- original[data.d,1]
test.data_labels <-original[-data.d,1]

train.data$PM=train.data_labels


#Tunning prameters
myControl <- trainControl(method="repeatedcv", 
                          number=10, 
                          repeats=3,
                          returnResamp='all', 
                          allowParallel=TRUE)

#Parameter for Tree Booster
#In the grid, each algorithm parameter can be specified as a vector of possible values . These vectors combine to define all the possible combinations to try.
# We will follow the defaults proposed by https://xgboost.readthedocs.io/en/latest//parameter.html

tune_grid <- expand.grid(nrounds = 200,           # the max number of iterations INCREASE THE PROCESSING TIME COST
                         max_depth = 6,            # depth of a tree EFFECTIVE OPTIMIZATION
                         eta = 0.3,               # control the learning rate
                         gamma = 0,             # minimum loss reduction required
                         colsample_bytree = 1,  # subsample ratio of columns when constructing each tree
                         min_child_weight = 1,     # minimum sum of instance weight (hessian) needed in a child 
                         subsample = 1)          # subsample ratio of the training instance

# Step 5 modeling
set.seed(849)
fit.xgb_train<- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ band5..MEAN+ band6..MEAN+dis_to_road, 
                data=train.data,
                method = "xgbTree",
                metric= "Accuracy",
                preProc = c("center", "scale"), 
                trControl = myControl,
                tuneGrid = tune_grid,
                tuneLength = 10)

fit.xgb_train$resample
fit.xgb_train$modelInfo
X.xgb = varImp(fit.xgb_train)
plot(X.xgb)


#Confusion Matrix - train data
p1<-predict(fit.xgb_train, test.data, type = "raw")
confusionMatrix(p1, as.factor(test.data_labels))  # using more deep tree, the accuracy linearly increases! 

######## Hyperparameter----

tune_grid2 <- expand.grid(nrounds = c(200,210),           # the max number of iterations INCREASE THE PROCESSING TIME COST
                          max_depth = c(6,18,22),            # depth of a tree EFFECTIVE OPTIMIZATION
                          eta = c(0.05,0.3,1),               # control the learning rate
                          gamma = c(0,0.01,0.1),             # minimum loss reduction required
                          colsample_bytree = c(0.75,1),  # subsample ratio of columns when constructing each tree
                          min_child_weight = c(0,1,2),     # minimum sum of instance weight (hessian) needed in a child 
                          subsample = c(0.5,1))            # subsample ratio of the training instance

set.seed(849)
fit.xgb_train2<- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ 
                         band5..MEAN+ band6..MEAN+dis_to_road, 
                       data=train.data,
                       method = "xgbTree",
                       metric= "Accuracy",
                       preProc = c("center", "scale"), 
                       trControl = myControl,
                       tuneGrid = tune_grid2,
                       tuneLength = 10)

summaryRes=fit.xgb_train2$results # nrounds was fixed = 210
head(summaryRes)
summary(summaryRes)
head(summaryRes[order(summaryRes$Accuracy, decreasing = TRUE),],n=6)  # sort max to min for first 5 values based on Accuracy
# Plot
pairs(summaryRes[,c(-7,-9:-11)])
# Save it
write.csv(fit.xgb_train2$results,file = "fit.xgb_train_hyper.csv")#, sep = "",row.names = T)

#### Read from saved file
#list.files( pattern = "csv$", full.names = TRUE)
#summaryRes <-  read.csv("./fit.xgb_train_hyper.csv", header = T,stringsAsFactors = FALSE)
#summaryRes=summaryRes[,c(-1,-8,-11:-12)] # nrounds was fixed = 210
#head(summaryRes)
#summary(summaryRes)
#head(summaryRes[order(summaryRes$Accuracy, decreasing = TRUE),],n=6)  # sort max to min for first 5 values based on Accuracy
# Plot
#pairs(summaryRes[-8])

# Re-run using recomended settings of expand.grid
tune_grid3 <- expand.grid(nrounds = c(200),           # the max number of iterations INCREASE THE PROCESSING TIME COST
                          max_depth = c(18),            # depth of a tree EFFECTIVE OPTIMIZATION
                          eta = c(0.03),               # control the learning rate
                          gamma = c(0.1),             # minimum loss reduction required
                          colsample_bytree = c(1),  # subsample ratio of columns when constructing each tree
                          min_child_weight = c(0),     # minimum sum of instance weight (hessian) needed in a child 
                          subsample = c(0.5))            # subsample ratio of the training instance

set.seed(849)
fit.xgb_train3<- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ 
                         band5..MEAN+ band6..MEAN+dis_to_road, 
                       data=train.data,
                       method = "xgbTree",
                       metric= "Accuracy",
                       preProc = c("center", "scale"), 
                       trControl = myControl,
                       tuneGrid = tune_grid3,
                       tuneLength = 10,
                       importance = TRUE)


fit.xgb_train3$results
X.xgb = varImp(fit.xgb_train3)
plot(X.xgb)
plot(fit.xgb_train3)

#Confusion Matrix - train data
p2_xgb_train3<-predict(fit.xgb_train3, test.data, type = "raw")
confusionMatrix(p2_xgb_train3, as.factor(test.data_labels))  # using more deep tree, the accuracy linearly increases! 
#while increase the iterations to 220 double the processing time with slight accuracy improvment!

# Plot ROC curves
# https://stackoverflow.com/questions/46124424/how-can-i-draw-a-roc-curve-for-a-randomforest-model-with-three-classes-in-r
#install.packages("pROC")
library(pROC)


# the model is used to predict the test data. However, you should ask for type="prob" here
predictions <- as.data.frame(predict(fit.xgb_train3, test.data, type = "prob"))

##  Since you have probabilities, use them to get the most-likely class.
# predict class and then attach test class
predictions$predict <- names(predictions)[1:3][apply(predictions[,1:3], 1, which.max)]
predictions$observed <- test.data_labels
head(predictions)

#    Now, let's see how to plot the ROC curves. For each class, convert the multi-class problem into a binary problem. Also, 
#    call the roc() function specifying 2 arguments: i) observed classes and ii) class probability (instead of predicted class).
# 1 ROC curve,  VUnheal, Good, UHealSesn vs non  VUnheal non Good non UHealSesn
roc.Good <- roc(ifelse(predictions$observed=="Good", "Good", "non-Good"), as.numeric(predictions$Good))
roc.VUnheal <- roc(ifelse(predictions$observed== "VUnheal", "VUnheal", "non-VUnheal"), as.numeric(predictions$VUnheal))
roc.UHealSesn <- roc(ifelse(predictions$observed=="UHealSesn", "UHealSesn", "non-UHealSesn"), as.numeric(predictions$UHealSesn))

plot(roc.VUnheal, col = "#FF9900", main="XGBoost best tune prediction ROC plot using testing data", xlim=c(0.64,0.1))
lines(roc.UHealSesn, col = "red")
lines(roc.Good, col = "green")

# calculating the values of AUC for ROC curve
results= c("UHealSesn AUC" = roc.UHealSesn$auc,"VUnheal AUC" = roc.VUnheal$auc,"Good AUC" = roc.Good$auc)
print(results)
legend("topleft",c("UHealSesn AUC = 0.93 ","VUnheal AUC = 0.94","Good AUC = 0.95"),fill=c("red","#FF9900","green"),inset = (0.42))


############################# EXTRA STARTED
# Continue  https://stackoverflow.com/questions/47820166/add-auc-by-group-on-roc-plots-in-r

# for more professional plots: 
# https://stackoverflow.com/questions/14860078/plot-multiple-lines-data-series-each-with-unique-color-in-r
# http://www.stat.columbia.edu/~tzheng/files/Rcolor.pdf
# http://www.cookbook-r.com/Graphs/Shapes_and_line_types/
brewer.pal(n = 3, name = "RdBu")
# Plot colors
library("RColorBrewer")
display.brewer.all()
############################# EXTRA FINISHED


#Train xgbTree model USING aLL dependent data
#We will use the train() function from the of caret package with the "method" parameter "xgbTree" wrapped from the XGBoost package.

original.n$PM=original$LevelAve
set.seed(849)
fit.xgbAll<- train(PM~BU..MEAN.+ LST..MEAN.+ SAVI..MEAN.+band2..MEAN+band3..MEAN+ band4..MEAN+ band5..MEAN+ band6..MEAN+dis_to_road, 
                      data=original.n,
                   method = "xgbTree",
                   metric= "Accuracy",
                   preProc = c("center", "scale"), 
                   trControl = myControl,
                   tuneGrid = tune_grid3,
                   tuneLength = 10,
                   importance = TRUE)

X.xgbAll = varImp(fit.xgbAll)
plot(X.xgbAll, main="varImportance XB All tunned")

# Plot graph
# 1. Open jpeg file
jpeg("varImportance XB All tunned.jpg", width = 800, height = 500)
# 2. Create the plot
plot(X.xgbAll,main="varImportance All XB" )
# 3. Close the file
dev.off()

####################################################################################################################################################################################################################################
###### http://www.sthda.com/english/articles/40-regression-analysis/166-predict-in-r-model-predictions-and-confidence-intervals/


# 6  Produce prediction map using Raster data --------------
#Produce prediction map using Trained model results and Raster layers data

# Load the Raster data
list.files( "H:/Projects/Kirkuk/WorkingDir/LST_ave",pattern = "tif$", full.names = TRUE)
LST..MEAN. = raster("H:/Projects/Kirkuk/WorkingDir/LST_ave/LST.tif" )
names(LST..MEAN.)="LST..MEAN."

list.files( "H:/Projects/Kirkuk/WorkingDir/SAVI_ave",pattern = "tif$", full.names = TRUE)
SAVI..MEAN. <-  raster("H:/Projects/Kirkuk/WorkingDir/SAVI_ave/SAVI.tif" ) 
names(SAVI..MEAN.)="SAVI..MEAN."

list.files( "H:/Projects/Kirkuk/WorkingDir/BU_ave",pattern = "tif$", full.names = TRUE)
BU..MEAN.= raster("H:/Projects/Kirkuk/WorkingDir/BU_ave/BU.tif" ) 
names(BU..MEAN.)="BU..MEAN."

list.files( "H:/Projects/Kirkuk/WorkingDir/B2_ave",pattern = "tif$", full.names = TRUE)
band2..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B2_ave/band2.tif")
names(band2..MEAN)="band2..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B3_ave",pattern = "tif$", full.names = TRUE)
band3..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B3_ave/band3.tif") 
names(band3..MEAN)="band3..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B4_ave",pattern = "tif$", full.names = TRUE)
band4..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B4_ave/band4.tif" ) 
names(band4..MEAN)="band4..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B5_ave",pattern = "tif$", full.names = TRUE)
band5..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B5_ave/band5.tif" ) 
names(band5..MEAN)="band5..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/B6_ave",pattern = "tif$", full.names = TRUE)
band6..MEAN= raster("H:/Projects/Kirkuk/WorkingDir/B6_ave/band6.tif" ) 
names(band6..MEAN)="band6..MEAN"

list.files( "H:/Projects/Kirkuk/WorkingDir/Roads",pattern = "tif$", full.names = TRUE)
dis_to_road= raster("H:/Projects/Kirkuk/WorkingDir/Roads/dist_to_road.tif" ) 
names(dis_to_road)="dis_to_road"
Study_area <- shapefile("G:/IKC/International projects/Kirkuk air pollution/Practical/study area focused.shp")
dis_to_road <- mask(crop(dis_to_road, Study_area), Study_area)


---------------#EXTRA----
# if you have diffrent extent, then try to Resample them using the smallest area
NDVI_r <- resample(NDVI,LST, resample='bilinear') 
SLOPE_r <- resample(SLOPE,LANDCOVER, resample='bilinear') 
TWI_r <- resample(TWI,LANDCOVER, resample='bilinear') 
CURVATURE_r <- resample(CURVATURE,LANDCOVER, resample='bilinear') 
SPI_r <- resample(SPI,LANDCOVER, resample='bilinear') 
ASPECT_r <- resample(ASPECT,LANDCOVER, resample='bilinear') 

extent(ASPECT_r) # check the new extent
extent(LANDCOVER)

# write to a new geotiff file
writeRaster(ASPECT_r,filename="resampled/ASPECT.tif", format="GTiff", overwrite=TRUE) 
writeRaster(SPI_r,filename="resampled/SPI.tif", format="GTiff", overwrite=TRUE)
writeRaster(CURVATURE_r,filename="resampled/CURVATURE.tif", format="GTiff", overwrite=TRUE)
writeRaster(TWI_r,filename="resampled/TWI.tif", format="GTiff", overwrite=TRUE)
writeRaster(ELEVATION_r,filename="resampled/ELEVATION.tif", format="GTiff", overwrite=TRUE)
writeRaster(SLOPE_r,filename="resampled/SLOPE.tif", format="GTiff", overwrite=TRUE)
writeRaster(LANDCOVER,filename="resampled/LANDCOVER.tif", format="GTiff", overwrite=TRUE)

#Stack_List= stack(ASPECT_r,LS_r)#,pattern = "tif$", full.names = TRUE)
#names(Stack_List)
#Stack_List.df = as.data.frame(Stack_List, xy = TRUE, na.rm = TRUE)
#head(Stack_List.df,1)

#--------------#-----


# check attributes and projection and extent
#extent()

# stack multiple raster files
#Stack
#Rasters<- stack(list.files( "G:/bda/Landsat 20180629 Auto Processed by ESPA/Training/June 2018",pattern = "tif$", full.names = TRUE))

Rasters<- stack(BU..MEAN.,LST..MEAN.,SAVI..MEAN.,band2..MEAN,band3..MEAN,band4..MEAN,band5..MEAN,band6..MEAN,dis_to_road)
plot(Rasters$LST..MEAN.)
names(Rasters)



# 6-1-1 Convert rasters to dataframe with Long-Lat -----------------------

#Convert raster to dataframe with Long-Lat
Rasters.df = as.data.frame(Rasters, xy = TRUE, na.rm = TRUE)
head(Rasters.df,1)
#Rasters.df=Rasters.df[,c(-6)] #

# Now:Prediction using imported Rasters
Rasters.df_N <- Rasters.df[,c(-1,-2)] # remove x, y

# Data Normalization
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }
# Keep the "LevelAve" variables since ita????s the response variable that needs to be predicted.
names(original)
Rasters.df_N_Nor <- as.data.frame(lapply(Rasters.df_N, normalize))    
str(Rasters.df_N_Nor)


#Convert Dataframe back to raster with Long-Lat
#https://stackoverflow.com/questions/19627344/how-to-create-a-raster-from-a-data-frame-in-r


# PRODUCE PROBABILITY MAP
p3<-as.data.frame(predict(fit.xgbAll, Rasters.df_N_Nor, type = "prob"))
summary(p3)
Rasters.df$Levels_VUnheal<-p3$VUnheal
Rasters.df$Levels_good<-p3$Good
Rasters.df$Levels_UHealSesn<-p3$UHealSesn

x<-SpatialPointsDataFrame(as.data.frame(Rasters.df)[, c("x", "y")], data = Rasters.df)
r_ave_good <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Levels_good")])
proj4string(r_ave_good)=CRS(projection(SAVI..MEAN.))

r_ave_VUnheal <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Levels_VUnheal")])
proj4string(r_ave_VUnheal)=CRS(projection(SAVI..MEAN.))

r_ave_UHealSesn <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Levels_UHealSesn")])
proj4string(r_ave_UHealSesn)=CRS(projection(SAVI..MEAN.))

# Plot Maps
spplot(r_ave_VUnheal, main="VUnheal XGB")
writeRaster(r_ave_VUnheal,filename="Prediction_XGBoostTunned_Ave_VUnheal.tif", format="GTiff", overwrite=TRUE) 

spplot(r_ave_UHealSesn, main="UHealSesn XGB")
writeRaster(r_ave_UHealSesn,filename="Prediction_XGBoostTunned_Ave_UHealSesn.tif", format="GTiff", overwrite=TRUE) 

spplot(r_ave_good, main="GOOD XGB")
writeRaster(r_ave_good,filename="Prediction_XGBoost Tunned_Ave_GOOD.tif", format="GTiff", overwrite=TRUE) 


# PRODUCE CLASSIFICATION MAP
#Prediction at grid location
p3<-as.data.frame(predict(fit.xgbAll, Rasters.df_N_Nor, type = "raw"))
summary(p3)
# Extract predicted levels class
head(Rasters.df, n=2)
Rasters.df$Levels_ave<-p3$`predict(fit.xgbAll, Rasters.df_N_Nor, type = "raw")`
head(Rasters.df, n=2)

# Import levels ID file 
ID<-read.csv("./Levels_key.csv", header = T)

# Join landuse ID
grid.new<-join(Rasters.df, ID, by="Levels_ave", type="inner") 
# Omit missing values
grid.new.na<-na.omit(grid.new)    
head(grid.new.na, n=2)

#Convert to raster
x<-SpatialPointsDataFrame(as.data.frame(grid.new.na)[, c("x", "y")], data = grid.new.na)
r_ave <- rasterFromXYZ(as.data.frame(x)[, c("x", "y", "Level_ID")])

# coord. ref. : NA 
# Add coord. ref. system by using the original data info (Copy n Paste).
# borrow the projection from Raster data
proj4string(r_ave)=CRS(projection(SAVI..MEAN.)) # set it to lat-long

# Export final prediction map as raster TIF ---------------------------
# write to a new geotiff file
writeRaster(r_ave,filename="Classification_Map XGBoost Tunned_Ave.tif", format="GTiff", overwrite=TRUE) 


#Plot Landuse Map:
# Color Palette follow Air index color style
#https://bookdown.org/rdpeng/exdata/plotting-and-color-in-r.html

myPalette <- colorRampPalette(c("light green","#FFFF00","#FFC600", "#FFAA00","#FF3800","#FF0200" ))

# Plot Map
LU_ave<-spplot(r_ave,"Level_ID", main="PM10 ave. concentration prediction: XGBoost tunned" , 
               colorkey = list(space="right",tick.number=1,height=1, width=1.5,
                               labels = list(at = seq(1,4.8,length=5),cex=1.0,
                                             lab = c("Good" ,"Moderate", "UHealSesn", "UHeal", "VUnheal", "Haz"))),
               col.regions=myPalette,cut=4)
LU_ave
jpeg("Prediction_Map XGBoost_AveAllRec.jpg", width = 1000, height = 700)
LU_ave
dev.off()





#   nrounds   max_depth  eta gamma colsample_bytree min_child_weight subsample      Accuracy    Kappa  AccuracySD     KappaSD
# 1     200        18     0.07     0.01             0.75                0       0.5 0.8131468 0.719717 0.003342402 0.005013939